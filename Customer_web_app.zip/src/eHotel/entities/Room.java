package eHotel.entities;

public class Room {

    private final String room_no;

    public Room(String room_no) {
        this.room_no = room_no;
    }

    public String getRoom_no() {
        return room_no;
    }

}
