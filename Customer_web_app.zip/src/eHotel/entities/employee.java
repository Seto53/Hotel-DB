package eHotel.entities;

public class employee {
	
//	employee here has employeeid and password attributes
	
	private String employee_id;
	private String employee_pass;
	
	public employee() {
		
	}

	public String getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}

	public String getEmployee_pass() {
		return employee_pass;
	}

	public void setEmployee_pass(String employee_pass) {
		this.employee_pass = employee_pass;
	}
	
	

}
